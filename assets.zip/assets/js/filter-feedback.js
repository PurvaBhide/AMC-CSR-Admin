
document.addEventListener('DOMContentLoaded', () => {
  fetchAndRenderFeedbackList(); // Load initial data

  // Event listeners for filters
  document.getElementById('monthSelect').addEventListener('change', function () {
    fetchFeedbackByMonth(this.value);
  });

  document.getElementById('ratingSelect').addEventListener('change', function () {
    fetchFeedbackByRating(this.value);
  });

  document.getElementById('dateSelect').addEventListener('change', function () {
    fetchFeedbackByDate(this.value);
  });
});

// Function to fetch all feedback
function fetchAndRenderFeedbackList() {
  const token = localStorage.getItem('token');
  fetch('https://mumbailocal.org:8085/api/getfeedback', {
    headers: {
      'Authorization': `Bearer ${token}`
    }
  })
    .then(response => response.json())
    .then(data => {
      if (!Array.isArray(data.content)) {
        console.error('Unexpected API response format:', data);
        return;
      }
      updateFeedbackTables(data.content);
    })
    .catch(error => {
      console.error('Error fetching feedback list:', error);
    });
}

// Function to fetch feedback by month
function fetchFeedbackByMonth(month) {
  const token = localStorage.getItem('token');
  const year = new Date().getFullYear(); // Get current year
  const url = `https://mumbailocal.org:8085/api/feedback/by-month?month=${month}&year=${year}`;

  fetch(url, {
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    }
  })
    .then(response => response.json())
    .then(data => {
      if (!Array.isArray(data)) {
        console.error('Unexpected API response format:', data);
        return;
      }
      updateFeedbackTables(data);
    })
    .catch(error => {
      console.error('Error fetching feedback by month:', error);
    });
}

// Function to fetch feedback by rating
function fetchFeedbackByRating(rating) {
  const token = localStorage.getItem('token');
  const url = `https://mumbailocal.org:8085/api/feedback/by-rating/${rating}`;

  fetch(url, {
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    }
  })
    .then(response => response.json())
    .then(data => {
      if (!Array.isArray(data)) {
        console.error('Unexpected API response format:', data);
        return;
      }
      updateFeedbackTables(data);
    })
    .catch(error => {
      console.error('Error fetching feedback by rating:', error);
    });
}

// Function to fetch feedback by date
function fetchFeedbackByDate(selectedDate) {
  const token = localStorage.getItem('token');
  const url = `https://mumbailocal.org:8085/api/feedback/by-date?date=${selectedDate}`;

  fetch(url, {
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    }
  })
    .then(response => response.json())
    .then(data => {
      if (!Array.isArray(data)) {
        console.error('Unexpected API response format:', data);
        return;
      }
      updateFeedbackTables(data);
    })
    .catch(error => {
      console.error('Error fetching feedback by date:', error);
    });
}

// Function to update feedback tables

function updateFeedbackTables(feedbackList) {
  const inProgressRows = [];
  const resolvedRows = [];
  let inProgressCount = 0;
  let resolvedCount = 0;

  feedbackList.forEach(feedback => {
    const status = feedback.complaintStatus; // Get complaint status
    const statusClass = status === 'Resolved' ? 'bg-success' :
                        status === 'Pending' ? 'bg-warning' : 'bg-primary';
    const escapedFeedback = encodeURIComponent(JSON.stringify(feedback));

    const tr = `
      <tr>
        <td>${status === 'Resolved' ? ++resolvedCount : ++inProgressCount}</td>
        <td>${feedback.userName}</td>
        <td>${feedback.contactNumber}</td>
        <td>${feedback.concerneddepartment}</td>
        <td><span class="badge ${statusClass}">${status}</span></td>
        <td>
          <button class="btn btn-primary btn-sm" onclick='handleEdit(JSON.parse(decodeURIComponent("${escapedFeedback}")))' >
            Edit
          </button>
        </td>
      </tr>
    `;

    if (status === 'Resolved') {
      resolvedRows.push(tr);
    } else {
      inProgressRows.push(tr);
    }
  });

  document.getElementById('inProgressTable').innerHTML = inProgressRows.join('');
  document.getElementById('resolvedTable').innerHTML = resolvedRows.join('');
}

document.addEventListener('DOMContentLoaded', () => {
  fetchPoliceStations(); // Populate the police station dropdown

  // Attach event listener for police station selection
  document.getElementById('policeStationSelect').addEventListener('change', event => {
    fetchFeedbackByPoliceStation(event.target.value);
  });
});

// Fetch and populate police stations
function fetchPoliceStations() {
  const token = localStorage.getItem('token');

  fetch('https://mumbailocal.org:8085/api/dashboard/getpolicestation', {
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    }
  })
    .then(response => response.json())
    .then(data => {
      const policeSelect = document.getElementById('policeStationSelect');
      policeSelect.innerHTML = `<option value="">Select Police Station</option>`;
      data.forEach(station => {
        policeSelect.innerHTML += `<option value="${station.policestationName}">${station.policestationName}</option>`;
      });
    })
    .catch(error => console.error('Error fetching police stations:', error));
}

// Fetch feedback by selected police station
function fetchFeedbackByPoliceStation(policeStationName) {
  if (!policeStationName?.trim()) return; // Check for empty or undefined input

  if (!policeStationName) return; // Do nothing if no selection is made

  const token = localStorage.getItem('token');
  console.log(policeStationName);
  console.log('Original policeStationName:', policeStationName);

  // Extract only the first word before the first space
  const firstWord = policeStationName.trim().split(' ')[0];

  console.log('Formatted policeStationName:', firstWord);
  // Replace space with '+' (if backend requires it)
  const formattedName = policeStationName.replace(/ /g, '+');

  const url = `https://mumbailocal.org:8085/api/feedback/by-police-station-name?policeStationName=${firstWord}`;

  fetch(url, {
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    }
  })
    .then(response => response.ok ? response.json() : Promise.reject(response))
    .then(data => {
      if (!Array.isArray(data)) {
        console.error('Unexpected API response format:', data);
        return;
      }
      updateFeedbackTables(data);
    })
    .catch(error => {
      console.error('Error fetching feedback:', error);
      alert('Failed to fetch feedback. Please try again.');
    });
}

// Function to update feedback tables
function updateFeedbackTables(feedbackList) {
  const inProgressRows = [];
  const resolvedRows = [];
  let inProgressCount = 0;
  let resolvedCount = 0;

  if (!feedbackList.length) {
    // Show a message if there is no data
    document.getElementById('inProgressTable').innerHTML = `
      <tr><td colspan="6" class="text-center">No feedback available</td></tr>`;
    document.getElementById('resolvedTable').innerHTML = `
      <tr><td colspan="6" class="text-center">No feedback available</td></tr>`;
    document.getElementById('inProgressPagination').style.display = 'none'; // Hide pagination if no data
    return;
  }

  feedbackList.forEach(feedback => {
    const { complaintStatus, userName, contactNumber, concerneddepartment } = feedback;
    const statusClass = complaintStatus === 'Resolved' ? 'bg-success' :
                        complaintStatus === 'Pending' ? 'bg-warning' : 'bg-primary';

    const tr = `
      <tr>
        <td>${complaintStatus === 'Resolved' ? ++resolvedCount : ++inProgressCount}</td>
        <td>${userName}</td>
        <td>${contactNumber}</td>
        <td>${concerneddepartment}</td>
        <td><span class="badge ${statusClass}">${complaintStatus}</span></td>
        <td>
          <button class="btn btn-primary btn-sm" data-feedback='${JSON.stringify(feedback)}' onclick="handleEditClick(this)">
            Edit
          </button>
        </td>
      </tr>
    `;

    complaintStatus === 'Resolved' ? resolvedRows.push(tr) : inProgressRows.push(tr);
  });

  document.getElementById('inProgressTable').innerHTML = inProgressRows.join('');
  document.getElementById('resolvedTable').innerHTML = resolvedRows.join('');
  document.getElementById('inProgressPagination').style.display = 'flex'; // Show pagination if data exists
}


// Safer way to handle editing feedback
function handleEditClick(button) {
  const feedback = JSON.parse(button.getAttribute('data-feedback'));
  handleEdit(feedback);
}

function filterFeedbackByDepartment(selectedDepartment) {
  const predefinedDepartments = [
    "Crime", "Law and Order", "Traffic Accidents",
    "Passport Verification", "Permissions",
    "Lost Property", "Cyber Crimes", "Police Protection"
  ];

  const isOtherCategory = selectedDepartment === "Other";

  // Get table rows from both tables
  const allRows = document.querySelectorAll("#inProgressTable tr, #resolvedTable tr");

  allRows.forEach(row => {
    const departmentCell = row.cells[3]?.textContent.trim(); // Read department from the table
    if (!departmentCell) return; // Skip if empty

    console.log("Row Department:", departmentCell, "| Selected:", selectedDepartment); // Debugging output

    if (selectedDepartment === "") {
      row.style.display = ""; // Show all if no department is selected
    } else if (isOtherCategory) {
      row.style.display = predefinedDepartments.includes(departmentCell) ? "none" : "";
    } else {
      row.style.display = departmentCell === selectedDepartment ? "" : "none";
    }
  });
}

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('department_issue').addEventListener('change', function () {
    const selectedDepartment = this.value;
    console.log("Dropdown Changed:", selectedDepartment); // Debugging
    filterFeedbackByDepartment(selectedDepartment);
  });
});
